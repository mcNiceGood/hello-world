$(function () {
    var lineChart = echarts.init(document.getElementById("echarts-line-chart"));
    var lineoption = {
        title : {
            text: ''
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['实时请求量','实时请求客户量','offer请求数量','规则使用数量']
        },      
        calculable : true,
        xAxis : [
            {
                type : 'category',
                boundaryGap : true,
                data : ['2017-5','2017-6','2017-7','2017-8']
            }
        ],
        yAxis : [
            {
                type : 'value',
                axisLabel : {
                    formatter: '{value} 个'
                }
            }
        ],
        series : [
        	
            {
                name:'实时请求量',
                type:'line',
                itemStyle : { normal: {label : {show: true}}},
                data:[1110, 1250, 900, 1400],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            },
            {
                name:'实时请求客户量',
                type:'line',
                itemStyle : { normal: {label : {show: true}}},
                data:[600, 550, 730, 490],              
                markPoint : {
                    data : [
                         {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name : '平均值'}
                    ]
                }
            },
             {
                name:'offer请求数量',
                type:'bar',
                
                data:[600, 550, 730, 490],              
//              barCategoryGap: '10%',
//				barGap:'5%' 			
            },
             {
                name:'规则使用数量',
                type:'bar', 				 
                data:[1110, 1250, 900, 1400],
                
            },
        ]
    };
    lineChart.setOption(lineoption);
    $(window).resize(lineChart.resize);

    var barChart = echarts.init(document.getElementById("echarts-bar-chart"));
    var baroption = {
        title : {
            text: '静态数据统计',
            subtext: '',
            x:'center'
        },
        tooltip : {
            show:true,
            formatter: '{a}<br/>{b}:{c}<br/>{d}%'
        },
        legend: {
            orient : 'vertical',
            x : 'left',
            data:['offer个数','手机银行','网点栏位个数','规则个数']
        },
        calculable : true,
        series : [
            {
                name:'静态数据',
                type:'pie',
                radius : '55%',
                
                center: ['50%', '60%'],
                data:[
                    {value:335, name:'offer个数'},
                    {value:310, name:'手机银行'},
                    {value:234, name:'网点栏位个数'},
                    {value:135, name:'规则个数'}
                ],
                 itemStyle: {
		           normal:{
		             label:{
		             show:true,
		             formatter: '{b} : {c} \n ({d}%)'
		             },
		             labelLine:{
		             show:true
		             }
		             },
		               emphasis: {
		                   shadowBlur: 10,
		                   shadowOffsetX: 0,
		                   shadowColor: 'rgba(0, 0, 0, 0.5)'
		               }
		           }
		       }
        ]
    };
    barChart.setOption(baroption);
    window.onresize = barChart.resize;
    $('.btn-danger').on('click',function(){
//  	console.log(onresize);
    	barChart.setOption({
    		  xAxis : [
	            {
	                type : 'category',
	                boundaryGap : false,
	                data : ['2017-5','2017-6','2017-7','2017-8','2017-9']
	            }
	        ],
    		series:[{
    			type:'line',
    			name:'实时请求量',
//  			'实时请求客户量','offer请求数量','规则使用数量'
    			data:[900, 600, 1300, 800]
    		}]
    	})
    	
    })

})